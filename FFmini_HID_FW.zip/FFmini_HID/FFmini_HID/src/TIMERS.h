

void TIMER0_init(void);

void TIMER1_init(void);

