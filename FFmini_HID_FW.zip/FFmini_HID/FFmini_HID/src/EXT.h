// External Interrupt header file
void EXT_INT_init(void);


